jQuery( function ( $ ) {
  $( '.learndash-wrapper .ld-focus header.et-l.et-l--header, .learndash-wrapper .ld-focus footer.et-l.et-l--footer' ).css( {
    'display': 'none',
  } );
} );